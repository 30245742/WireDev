import pygame
import sys

# Constants for screen dimensions and tile size
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
TILE_SIZE = 40

# Basic colors (R, G, B)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (100, 100, 100)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

class Player:
    """
    The Player class handles player-specific data (position, movement, sprite).
    In Version 1, the player is represented as a simple rectangle.
    """
    def __init__(self, start_x, start_y):
        # (start_x, start_y) are in tile coordinates, so multiply by TILE_SIZE for pixels
        self.rect = pygame.Rect(start_x * TILE_SIZE, start_y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
        self.speed = 4  # Speed in pixels per frame

    def move(self, dx, dy, walls):
        """
        Moves the player by (dx, dy) in pixels, checking collision against wall tiles.

        :param dx: movement in x direction
        :param dy: movement in y direction
        :param walls: list of Rect objects representing wall tiles
        """
        # Move horizontally
        self.rect.x += dx
        # If we collide with a wall, reverse the move
        if self.check_collision(walls):
            self.rect.x -= dx

        # Move vertically
        self.rect.y += dy
        # If we collide with a wall, reverse the move
        if self.check_collision(walls):
            self.rect.y -= dy

    def check_collision(self, walls):
        """
        Check if the player's rectangle intersects any wall rectangles.

        :param walls: list of Rect objects representing wall tiles
        :return: True if collision is detected, False otherwise
        """
        for wall in walls:
            if self.rect.colliderect(wall):
                return True
        return False

class Game:
    """
    The Game class manages the main gameplay loop, including:
    - Creating/drawing the map
    - Initializing/drawing the player
    - Handling keyboard input
    """
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()

        # A sample tile-based map using a simple list of strings:
        # 'W' = wall, '.' = floor/free space
        self.tile_map = [
            "WWWWWWWWWWWWWW",
            "W............W",
            "W............W",
            "W..WWWWWWWW..W",
            "W............W",
            "W............W",
            "WWWWWWWWWWWWWW"
        ]

        # Generate walls (pygame.Rect) for collision detection
        self.walls = []
        self.load_map()

        # Initialize player at a free space in tile coordinates (x=1, y=1)
        self.player = Player(1, 1)

    def load_map(self):
        """
        Converts the tile map from strings into wall Rect objects for collision detection.
        """
        for row_index, row in enumerate(self.tile_map):
            for col_index, tile in enumerate(row):
                if tile == 'W':  # 'W' = wall
                    wall_rect = pygame.Rect(
                        col_index * TILE_SIZE,  # x pixel position
                        row_index * TILE_SIZE,  # y pixel position
                        TILE_SIZE,
                        TILE_SIZE
                    )
                    self.walls.append(wall_rect)

    def run(self):
        """
        The main loop for the game state.
        Listens for keyboard input and updates/draws the player accordingly.
        """
        running = True
        while running:
            self.clock.tick(60)  # Limit to 60 FPS

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            # Handle key presses for movement
            keys = pygame.key.get_pressed()
            dx, dy = 0, 0

            if keys[pygame.K_UP] or keys[pygame.K_w]:
                dy = -self.player.speed
            if keys[pygame.K_DOWN] or keys[pygame.K_s]:
                dy = self.player.speed
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                dx = -self.player.speed
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                dx = self.player.speed

            # Move the player
            self.player.move(dx, dy, self.walls)

            # Draw everything
            self.draw()

    def draw(self):
        """
        Clears the screen, draws the map and the player, then updates the display.
        """
        self.screen.fill(BLACK)

        # Draw the walls
        for wall in self.walls:
            pygame.draw.rect(self.screen, BLUE, wall)

        # Draw the player as a green rectangle
        pygame.draw.rect(self.screen, GREEN, self.player.rect)

        pygame.display.flip()

class MainMenu:
    """
    MainMenu handles drawing the initial menu with two buttons:
    - Start
    - Quit

    Clicking Start transitions to the Game loop; clicking Quit exits.
    """
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()

        # Defining button rectangles
        self.start_button = pygame.Rect((SCREEN_WIDTH // 2) - 60, 200, 120, 50)
        self.quit_button = pygame.Rect((SCREEN_WIDTH // 2) - 60, 280, 120, 50)

    def run(self):
        """
        The main loop for the menu state.
        """
        font = pygame.font.SysFont(None, 32)  # For button text
        running = True

        while running:
            self.clock.tick(60)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = event.pos

                    # Check Start button click
                    if self.start_button.collidepoint(mouse_pos):
                        # Transition to the main game
                        game = Game(self.screen)
                        game.run()

                    # Check Quit button click
                    if self.quit_button.collidepoint(mouse_pos):
                        pygame.quit()
                        sys.exit()

            # Draw menu
            self.screen.fill(GRAY)

            # Draw buttons
            pygame.draw.rect(self.screen, WHITE, self.start_button)
            pygame.draw.rect(self.screen, WHITE, self.quit_button)

            # Draw text for the buttons
            start_text = font.render("START", True, BLACK)
            quit_text = font.render("QUIT", True, BLACK)

            self.screen.blit(
                start_text,
                (self.start_button.x + (self.start_button.width - start_text.get_width()) // 2,
                 self.start_button.y + (self.start_button.height - start_text.get_height()) // 2)
            )
            self.screen.blit(
                quit_text,
                (self.quit_button.x + (self.quit_button.width - quit_text.get_width()) // 2,
                 self.quit_button.y + (self.quit_button.height - quit_text.get_height()) // 2)
            )

            pygame.display.flip()

def main():
    """
    Sets up the Pygame environment and starts the main menu.
    """
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Pac-Man Style Prototype - Version 1")

    main_menu = MainMenu(screen)
    main_menu.run()

if __name__ == "__main__":
    main()
