import pygame
import sys
import random

# Screen dimensions based on a 32x12 grid at 20px each
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 240
TILE_SIZE = 20

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE  = (0, 0, 255)
GREEN = (0, 255, 0)
YELLOW= (255, 255, 0)

class Player:
    def __init__(self, start_x, start_y):
        # Smaller player sprite (14x14) to fit corridors
        offset = (TILE_SIZE - 14) // 2
        self.rect = pygame.Rect(
            start_x * TILE_SIZE + offset,
            start_y * TILE_SIZE + offset,
            14, 14
        )
        self.speed = 3

    def move(self, dx, dy, walls):
        self.rect.x += dx
        if any(self.rect.colliderect(w) for w in walls):
            self.rect.x -= dx
        self.rect.y += dy
        if any(self.rect.colliderect(w) for w in walls):
            self.rect.y -= dy

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()

        # Your custom tile_map (32 columns x 12 rows)
        self.tile_map = [
            "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
            "W..................WWW.........W",
            "WWWWWWWWWWWW....W.....W.WWWWWWWW",
            "W..........W..W.W...W...W....W.W",
            "WWW...WWWWWW..W.W.W.WW..WWW....W",
            "W.W...W.........W.W..WW...W.WWWW",
            "W...........WWWWW.....W...W.W..W",
            "WWWWWWW.....W...WWWWW.W...W.W..W",
            "WW..............W..............W",
            "WWWWWWWWWWWW....W..WW...WWWWWWWW",
            "W............W.................W",
            "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
        ]

        # Wall rects
        self.walls = []
        self.load_map()

        # Player spawn near top-left
        self.player = Player(1, 1)

        # Score tracking
        self.score = 0

        # Orbs
        self.orb_size = 6
        self.orb_positions = []
        self.spawn_orbs(count=15)  # initial batch

        # Font for score
        self.font = pygame.font.SysFont(None, 24)

    def load_map(self):
        for row_idx, row in enumerate(self.tile_map):
            for col_idx, tile in enumerate(row):
                if tile == 'W':
                    rect = pygame.Rect(
                        col_idx * TILE_SIZE,
                        row_idx * TILE_SIZE,
                        TILE_SIZE, TILE_SIZE
                    )
                    self.walls.append(rect)

    def spawn_orbs(self, count=10):
        # Get all floor tiles ('.')
        floor_tiles = []
        for r, row in enumerate(self.tile_map):
            for c, tile in enumerate(row):
                if tile == '.':
                    floor_tiles.append((c, r))
        # Pick random spots
        self.orb_positions = []
        chosen = random.sample(floor_tiles, min(count, len(floor_tiles)))
        for (cx, ry) in chosen:
            # Center orb in tile
            x = cx * TILE_SIZE + (TILE_SIZE - self.orb_size)//2
            y = ry * TILE_SIZE + (TILE_SIZE - self.orb_size)//2
            self.orb_positions.append(pygame.Rect(x, y, self.orb_size, self.orb_size))

    def run(self):
        while True:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            # Movement
            dx = dy = 0
            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP] or keys[pygame.K_w]:
                dy = -self.player.speed
            if keys[pygame.K_DOWN] or keys[pygame.K_s]:
                dy = self.player.speed
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                dx = -self.player.speed
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                dx = self.player.speed

            self.player.move(dx, dy, self.walls)
            self.check_orb_collisions()
            self.draw()

            # If no orbs remain, spawn more
            if not self.orb_positions:
                self.spawn_orbs(count=15)

    def check_orb_collisions(self):
        for orb in self.orb_positions[:]:
            if self.player.rect.colliderect(orb):
                self.orb_positions.remove(orb)
                self.score += 1

    def draw(self):
        self.screen.fill(BLACK)
        for w in self.walls:
            pygame.draw.rect(self.screen, BLUE, w)
        # Draw orbs as small circles or squares
        for orb in self.orb_positions:
            pygame.draw.rect(self.screen, YELLOW, orb)
        pygame.draw.rect(self.screen, GREEN, self.player.rect)

        # Draw score
        score_text = self.font.render(f"Score: {self.score}", True, WHITE)
        self.screen.blit(score_text, (10, 5))

        pygame.display.flip()

class MainMenu:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.start_button = pygame.Rect((SCREEN_WIDTH // 2) - 60, 60, 120, 40)
        self.quit_button  = pygame.Rect((SCREEN_WIDTH // 2) - 60, 120, 120, 40)
        self.font = pygame.font.SysFont(None, 28)

    def run(self):
        while True:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    if self.start_button.collidepoint(pos):
                        Game(self.screen).run()
                    elif self.quit_button.collidepoint(pos):
                        pygame.quit()
                        sys.exit()

            self.screen.fill((100, 100, 100))
            pygame.draw.rect(self.screen, WHITE, self.start_button)
            pygame.draw.rect(self.screen, WHITE, self.quit_button)

            start_text = self.font.render("START", True, BLACK)
            quit_text  = self.font.render("QUIT",  True, BLACK)
            self.screen.blit(start_text, (
                self.start_button.x + (self.start_button.width - start_text.get_width()) // 2,
                self.start_button.y + (self.start_button.height - start_text.get_height()) // 2
            ))
            self.screen.blit(quit_text, (
                self.quit_button.x + (self.quit_button.width - quit_text.get_width()) // 2,
                self.quit_button.y + (self.quit_button.height - quit_text.get_height()) // 2
            ))

            pygame.display.flip()

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Pac-Man Prototype - Version 3")
    MainMenu(screen).run()

if __name__ == "__main__":
    main()
