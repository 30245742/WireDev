import pygame
import sys

SCREEN_WIDTH = 640   # 32 tiles * 20 px
SCREEN_HEIGHT = 480  # 24 tiles * 20 px
TILE_SIZE = 20

# Basic colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (100, 100, 100)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

class Player:
    def __init__(self, start_x, start_y):
        # Position the player in the center of the tile with a smaller rect (14x14)
        offset = (TILE_SIZE - 14) // 2
        self.rect = pygame.Rect(
            start_x * TILE_SIZE + offset,
            start_y * TILE_SIZE + offset,
            14,
            14
        )
        self.speed = 3

    def move(self, dx, dy, walls):
        # Horizontal move
        self.rect.x += dx
        if self.check_collision(walls):
            self.rect.x -= dx
        # Vertical move
        self.rect.y += dy
        if self.check_collision(walls):
            self.rect.y -= dy

    def check_collision(self, walls):
        for wall in walls:
            if self.rect.colliderect(wall):
                return True
        return False

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        # 24 rows x 32 columns, each character is a tile of size 20x20
        self.tile_map = [
            "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
            "W..................WWW.........W",
            "WWWWWWWWWWWW....W.....W.WWWWWWWW",
            "W..........W..W.W...W...W....W.W",
            "WWW...WWWWWW..W.W.W.WW..WWW....W",
            "W.W...W.........W.W..WW...W.WWWW",
            "W...........WWWWW.....W...W.W..W",
            "WWWWWWW.....W...WWWWW.W...W.W..W",
            "WW..............W..............W",
            "WWWWWWWWWWWW....W..WW...WWWWWWWW",
            "W............W.................W",
            "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
        ]

        # Convert map to wall rects
        self.walls = []
        self.load_map()

        # Place player near top-left inside the maze
        self.player = Player(1, 1)

    def load_map(self):
        for row_idx, row in enumerate(self.tile_map):
            for col_idx, tile in enumerate(row):
                if tile == 'W':
                    wall_rect = pygame.Rect(
                        col_idx * TILE_SIZE,
                        row_idx * TILE_SIZE,
                        TILE_SIZE,
                        TILE_SIZE
                    )
                    self.walls.append(wall_rect)

    def run(self):
        running = True
        while running:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            # Movement input
            keys = pygame.key.get_pressed()
            dx = dy = 0
            if keys[pygame.K_UP] or keys[pygame.K_w]:
                dy = -self.player.speed
            if keys[pygame.K_DOWN] or keys[pygame.K_s]:
                dy = self.player.speed
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                dx = -self.player.speed
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                dx = self.player.speed

            self.player.move(dx, dy, self.walls)
            self.draw()

    def draw(self):
        self.screen.fill(BLACK)
        for wall in self.walls:
            pygame.draw.rect(self.screen, BLUE, wall)
        pygame.draw.rect(self.screen, GREEN, self.player.rect)
        pygame.display.flip()

class MainMenu:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.start_button = pygame.Rect((SCREEN_WIDTH // 2) - 60, 200, 120, 50)
        self.quit_button = pygame.Rect((SCREEN_WIDTH // 2) - 60, 280, 120, 50)

    def run(self):
        font = pygame.font.SysFont(None, 32)
        while True:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = event.pos
                    if self.start_button.collidepoint(mouse_pos):
                        game = Game(self.screen)
                        game.run()
                    elif self.quit_button.collidepoint(mouse_pos):
                        pygame.quit()
                        sys.exit()

            self.screen.fill(GRAY)
            pygame.draw.rect(self.screen, WHITE, self.start_button)
            pygame.draw.rect(self.screen, WHITE, self.quit_button)
            start_text = font.render("START", True, BLACK)
            quit_text = font.render("QUIT", True, BLACK)
            self.screen.blit(
                start_text,
                (
                    self.start_button.x + (self.start_button.width - start_text.get_width()) // 2,
                    self.start_button.y + (self.start_button.height - start_text.get_height()) // 2
                )
            )
            self.screen.blit(
                quit_text,
                (
                    self.quit_button.x + (self.quit_button.width - quit_text.get_width()) // 2,
                    self.quit_button.y + (self.quit_button.height - quit_text.get_height()) // 2
                )
            )
            pygame.display.flip()

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Pac-Man Maze - Version 2")
    main_menu = MainMenu(screen)
    main_menu.run()

if __name__ == "__main__":
    main()
