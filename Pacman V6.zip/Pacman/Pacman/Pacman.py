import pygame
import sys
import random

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 500
TILE_SIZE = 20

BLACK  = (0, 0, 0)
WHITE  = (255, 255, 255)
BLUE   = (0, 0, 255)
GREEN  = (0, 255, 0)
YELLOW = (255, 255, 0)
GRAY   = (100, 100, 100)

# Session-based top 3
LEADERBOARD = []

class Player:
    def __init__(self, start_x, start_y):
        offset = (TILE_SIZE - 14) // 2
        self.rect = pygame.Rect(start_x*TILE_SIZE+offset, start_y*TILE_SIZE+offset, 14, 14)
        self.speed = 3

    def move(self, dx, dy, walls):
        self.rect.x += dx
        if any(self.rect.colliderect(w) for w in walls):
            self.rect.x -= dx
        self.rect.y += dy
        if any(self.rect.colliderect(w) for w in walls):
            self.rect.y -= dy

class Ghost:
    def __init__(self, x, y):
        offset = (TILE_SIZE - 14) // 2
        self.rect = pygame.Rect(x*TILE_SIZE+offset, y*TILE_SIZE+offset, 14, 14)
        self.speed = 2
        # Random direction on init
        self.dx, self.dy = random.choice([(1,0),(-1,0),(0,1),(0,-1)])
        self.change_dir_time = 0  # Counter for when to pick a new direction

    def update(self, dt, walls):
        # Move ghost
        self.rect.x += self.dx * self.speed
        if any(self.rect.colliderect(w) for w in walls):
            self.rect.x -= self.dx * self.speed
            self.new_direction()
        self.rect.y += self.dy * self.speed
        if any(self.rect.colliderect(w) for w in walls):
            self.rect.y -= self.dy * self.speed
            self.new_direction()

        # After some time, choose a new direction
        self.change_dir_time += dt
        if self.change_dir_time > 1.5:  # every ~1.5s pick new direction
            self.new_direction()

    def new_direction(self):
        self.dx, self.dy = random.choice([(1,0),(-1,0),(0,1),(0,-1)])
        self.change_dir_time = 0

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()

        # Custom tile map (unchanged from v5)
        self.tile_map = [
            "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
            "W..................WWW.........W",
            "WWWWWWWWWWWW....W.....W.WWWWWWWW",
            "W..........W..W.W...W...W....W.W",
            "WWW...WWWWWW..W.W.W.WW..WWW....W",
            "W.W...W.........W.W..WW...W.WWWW",
            "W...........WWWWW.....W...W.W..W",
            "WWWWWWW.....W...WWWWW.W...W.W..W",
            "WW..............W..............W",
            "WWWWWWWWWWWW....W..WW...WWWWWWWW",
            "W............W.................W",
            "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
        ]
        self.walls = []
        self.load_map()

        self.player = Player(1, 1)
        self.score = 0

        # Spawn orbs (15)
        self.orb_size = 6
        self.orb_positions = []
        self.spawn_orbs(15)

        # 60-second timer
        self.time_left = 60

        # Create 3 ghosts at random floor positions
        self.ghosts = []
        self.spawn_ghosts(3)

        self.font_small = pygame.font.SysFont(None, 24)
        self.font_med   = pygame.font.SysFont(None, 32)

    def load_map(self):
        for r_idx, row in enumerate(self.tile_map):
            for c_idx, tile in enumerate(row):
                if tile == 'W':
                    self.walls.append(pygame.Rect(
                        c_idx*TILE_SIZE,
                        r_idx*TILE_SIZE,
                        TILE_SIZE, TILE_SIZE
                    ))

    def spawn_orbs(self, count):
        floor_tiles = [(c, r) for r, row in enumerate(self.tile_map)
                       for c, t in enumerate(row) if t == '.']
        chosen = random.sample(floor_tiles, min(count, len(floor_tiles)))
        self.orb_positions.clear()
        for cx, ry in chosen:
            x = cx*TILE_SIZE + (TILE_SIZE - self.orb_size)//2
            y = ry*TILE_SIZE + (TILE_SIZE - self.orb_size)//2
            self.orb_positions.append(pygame.Rect(x, y, self.orb_size, self.orb_size))

    def spawn_ghosts(self, count):
        floor_tiles = [(c, r) for r, row in enumerate(self.tile_map)
                       for c, t in enumerate(row) if t == '.']
        chosen = random.sample(floor_tiles, min(count, len(floor_tiles)))
        for cx, ry in chosen:
            self.ghosts.append(Ghost(cx, ry))

    def run(self):
        while True:
            dt = self.clock.tick(60) / 1000.0
            self.time_left -= dt
            if self.time_left <= 0:
                return self.game_over()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            # Player movement
            dx = dy = 0
            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP] or keys[pygame.K_w]:
                dy = -self.player.speed
            if keys[pygame.K_DOWN] or keys[pygame.K_s]:
                dy = self.player.speed
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                dx = -self.player.speed
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                dx = self.player.speed
            self.player.move(dx, dy, self.walls)

            # Update ghosts
            for ghost in self.ghosts:
                ghost.update(dt, self.walls)
                # If ghost collides with player, game ends immediately
                if self.player.rect.colliderect(ghost.rect):
                    return self.game_over()

            # Orbs
            self.check_orb_collisions()
            if not self.orb_positions:
                self.spawn_orbs(15)

            self.draw()

    def check_orb_collisions(self):
        for orb in self.orb_positions[:]:
            if self.player.rect.colliderect(orb):
                self.orb_positions.remove(orb)
                self.score += 1

    def draw(self):
        self.screen.fill(BLACK)
        # Walls
        for w in self.walls:
            pygame.draw.rect(self.screen, BLUE, w)
        # Orbs
        for orb in self.orb_positions:
            pygame.draw.rect(self.screen, YELLOW, orb)
        # Ghosts
        for ghost in self.ghosts:
            pygame.draw.rect(self.screen, (255, 0, 0), ghost.rect)
        # Player
        pygame.draw.rect(self.screen, GREEN, self.player.rect)

        # UI
        sc_surf = self.font_small.render(f"Score: {self.score}", True, WHITE)
        tm_surf = self.font_small.render(f"Time: {int(self.time_left)}", True, WHITE)
        self.screen.blit(sc_surf, (10, 5))
        self.screen.blit(tm_surf, (10, 25))

        pygame.display.flip()

    def game_over(self):
        global LEADERBOARD
        LEADERBOARD.append(self.score)
        LEADERBOARD = sorted(LEADERBOARD, reverse=True)[:3]
        return GameOver(self.screen, self.score).run()

class GameOver:
    def __init__(self, screen, final_score):
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.final_score = final_score
        self.font_med   = pygame.font.SysFont(None, 36)
        self.font_small = pygame.font.SysFont(None, 24)

        # Buttons
        self.play_again_btn = pygame.Rect((SCREEN_WIDTH//2)-60, 100, 120, 40)
        self.quit_btn       = pygame.Rect((SCREEN_WIDTH//2)-60, 160, 120, 40)

    def run(self):
        while True:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    if self.play_again_btn.collidepoint(pos):
                        return True
                    elif self.quit_btn.collidepoint(pos):
                        pygame.quit()
                        sys.exit()
            self.draw()

    def draw(self):
        self.screen.fill(GRAY)
        game_over_surf = self.font_med.render("Game Over!", True, BLACK)
        score_surf     = self.font_med.render(f"Score: {self.final_score}", True, BLACK)
        self.screen.blit(game_over_surf, ((SCREEN_WIDTH - game_over_surf.get_width())//2, 20))
        self.screen.blit(score_surf,     ((SCREEN_WIDTH - score_surf.get_width())//2, 50))

        # Leaderboard
        y_offset = 220
        lb_title = self.font_small.render("Leaderboard:", True, BLACK)
        self.screen.blit(lb_title, ((SCREEN_WIDTH - lb_title.get_width())//2, y_offset))
        y_offset += 25
        for i, val in enumerate(LEADERBOARD, start=1):
            text = self.font_small.render(f"#{i} - {val} points", True, BLACK)
            self.screen.blit(text, ((SCREEN_WIDTH - text.get_width())//2, y_offset))
            y_offset += 20

        # Buttons
        pygame.draw.rect(self.screen, WHITE, self.play_again_btn)
        pygame.draw.rect(self.screen, WHITE, self.quit_btn)
        pa_text = self.font_small.render("Play Again", True, BLACK)
        q_text  = self.font_small.render("Quit",       True, BLACK)
        self.screen.blit(pa_text, (
            self.play_again_btn.x + (self.play_again_btn.width - pa_text.get_width())//2,
            self.play_again_btn.y + (self.play_again_btn.height - pa_text.get_height())//2
        ))
        self.screen.blit(q_text, (
            self.quit_btn.x + (self.quit_btn.width - q_text.get_width())//2,
            self.quit_btn.y + (self.quit_btn.height - q_text.get_height())//2
        ))
        pygame.display.flip()

class MainMenu:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont(None, 28)
        self.start_button = pygame.Rect((SCREEN_WIDTH//2)-60, 60, 120, 40)
        self.quit_button  = pygame.Rect((SCREEN_WIDTH//2)-60, 120, 120, 40)

    def run(self):
        while True:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    if self.start_button.collidepoint(pos):
                        again = Game(self.screen).run()
                        if again:  # If user pressed 'Play Again' in game over
                            continue
                        else:
                            return
                    elif self.quit_button.collidepoint(pos):
                        pygame.quit()
                        sys.exit()
            self.draw()

    def draw(self):
        self.screen.fill(GRAY)
        pygame.draw.rect(self.screen, WHITE, self.start_button)
        pygame.draw.rect(self.screen, WHITE, self.quit_button)
        s_text = self.font.render("START", True, BLACK)
        q_text = self.font.render("QUIT",  True, BLACK)
        self.screen.blit(s_text, (
            self.start_button.x + (self.start_button.width - s_text.get_width())//2,
            self.start_button.y + (self.start_button.height - s_text.get_height())//2
        ))
        self.screen.blit(q_text, (
            self.quit_button.x + (self.quit_button.width - q_text.get_width())//2,
            self.quit_button.y + (self.quit_button.height - q_text.get_height())//2
        ))
        pygame.display.flip()

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Pac-Man Prototype - Version 6")
    MainMenu(screen).run()

if __name__ == "__main__":
    main()
